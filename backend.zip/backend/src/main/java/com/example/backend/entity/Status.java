package com.example.backend.entity;

public enum Status {
    TODO,
    IN_PROGRESS,
    DONE
}