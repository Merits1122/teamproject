package com.example.backend.entity.project;

public enum ProjectInvitationStatus {
    PENDING,  // 초대 발송
    ACCEPTED, // 초대 수락
    DECLINED  // 초대 거절
}