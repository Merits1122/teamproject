package com.example.backend.entity;

public enum TaskPriority {
    LOW,
    MEDIUM,
    HIGH
}